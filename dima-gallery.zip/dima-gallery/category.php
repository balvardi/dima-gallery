<?php
require_once 'includes/db.php';

$category_id = intval($_GET['id']);
$filter = $_GET['filter'] ?? 'latest';

// دریافت نام دسته
$stmt = $pdo->prepare("SELECT name FROM categories WHERE id = ?");
$stmt->execute([$category_id]);
$category = $stmt->fetch();

if (!$category) {
    die("دسته یافت نشد.");
}

// دریافت طرح‌ها با فیلتر
switch ($filter) {
    case 'popular':
        $order = "views DESC";
        break;
    case 'downloaded':
        $order = "downloads DESC";
        break;
    default:
        $order = "created_at DESC";
}

$stmt = $pdo->prepare("
    SELECT d.id, d.title, d.preview_image, d.downloads, d.views 
    FROM designs d 
    WHERE d.category_id = ? AND d.status = 'approved'
    ORDER BY $order
");
$stmt->execute([$category_id]);
$designs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>دسته‌بندی <?= htmlspecialchars($category['name']) ?></title>
    <script src=" https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-white shadow p-4">
    <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-xl font-bold">دسته: <?= htmlspecialchars($category['name']) ?></h1>
        <div class="space-x-2 space-x-reverse">
            <a href="?id=<?= $category_id ?>&filter=latest" class="<?= $filter == 'latest' ? 'font-bold' : '' ?>">جدیدترین</a>
            <a href="?id=<?= $category_id ?>&filter=popular" class="<?= $filter == 'popular' ? 'font-bold' : '' ?>">پربازدیدترین</a>
            <a href="?id=<?= $category_id ?>&filter=downloaded" class="<?= $filter == 'downloaded' ? 'font-bold' : '' ?>">پرداولودترین</a>
        </div>
    </div>
</header>

<!-- Designs Grid -->
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php foreach ($designs as $d): ?>
            <div class="bg-white rounded shadow overflow-hidden card">
                <img src="<?= htmlspecialchars($d['preview_image']) ?>" alt="<?= htmlspecialchars($d['title']) ?>" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="font-semibold"><?= htmlspecialchars($d['title']) ?></h3>
                    <div class="text-sm text-gray-500 mt-2">
                        <p>دانلود: <?= number_format($d['downloads']) ?></p>
                        <p>بازدید: <?= number_format($d['views']) ?></p>
                    </div>
                    <a href="single.php?id=<?= $d['id'] ?>" class="text-blue-500 hover:underline mt-2 inline-block">مشاهده</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>