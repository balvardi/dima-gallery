<?php
session_start();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['db_host'];
    $dbname = $_POST['db_name'];
    $username = $_POST['db_user'];
    $password = $_POST['db_pass'];
    $admin_email = $_POST['admin_email'];
    $admin_password = password_hash($_POST['admin_pass'], PASSWORD_DEFAULT);
    $admin_name = $_POST['admin_name'];

    try {
        // اتصال به دیتابیس
        $pdo = new PDO("mysql:host={$host}", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // ایجاد دیتابیس
        $pdo->exec("CREATE DATABASE IF NOT EXISTS {$dbname} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        // اتصال به دیتابیس
        $pdo = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // ایجاد جداول
        $sql = file_get_contents(__DIR__ . '/../../install.sql');
        if (!$sql) {
            throw new Exception("فایل install.sql یافت نشد یا خالی است.");
        }

        $pdo->exec($sql);

        // ایجاد ادمین اولیه
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'admin')");
        $stmt->execute([$admin_name, $admin_email, $admin_password]);

        // ذخیره تنظیمات در config.php
        $config_content = "<?php\n";
        $config_content .= "define('DB_HOST', '" . $host . "');\n";
        $config_content .= "define('DB_NAME', '" . $dbname . "');\n";
        $config_content .= "define('DB_USER', '" . $username . "');\n";
        $config_content .= "define('DB_PASS', '" . $password . "');\n";
        file_put_contents(__DIR__ . '/../../includes/config.php', $config_content);

        $success = "✅ نصب با موفقیت انجام شد!<br>دیتابیس ایجاد شد و ادمین ثبت شد.<br><a href='../login.php' class='text-blue-600 hover:underline'>ورود به سایت</a>";

    } catch (Exception $e) {
        $error = "❌ خطای نصب: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نصب Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100 p-6">

<div class="max-w-xl mx-auto bg-white rounded shadow p-6">
    <h1 class="text-2xl font-bold mb-6">نصب Dima Gallery</h1>

    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= $success ?></div>
    <?php else: ?>
        <form method="post">
            <!-- Database Settings -->
            <h2 class="text-lg font-semibold mb-4">تنظیمات دیتابیس</h2>
            <div class="grid grid-cols-1 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">هاست</label>
                    <input type="text" name="db_host" value="localhost" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">نام دیتابیس</label>
                    <input type="text" name="db_name" value="dima_gallery" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">نام کاربری دیتابیس</label>
                    <input type="text" name="db_user" value="root" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">رمز دیتابیس</label>
                    <input type="password" name="db_pass" value="" class="w-full border rounded px-3 py-2">
                </div>
            </div>

            <!-- Admin Account -->
            <h2 class="text-lg font-semibold mb-4">حساب ادمین اولیه</h2>
            <div class="grid grid-cols-1 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">نام ادمین</label>
                    <input type="text" name="admin_name" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">ایمیل ادمین</label>
                    <input type="email" name="admin_email" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">رمز عبور ادمین</label>
                    <input type="password" name="admin_pass" required class="w-full border rounded px-3 py-2">
                </div>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full">
                نصب کن
            </button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>