<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = "توکن CSRF معتبر نیست.";
    } else {
        $name = clean_input($_POST['name']);
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        if (!$name || !$email || !$password) {
            $error = "لطفاً تمام فیلدها را پر کنید.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $password]);
                $success = "ثبت‌نام موفق! حالا می‌توانید وارد شوید.";
            } catch (PDOException $e) {
                $error = "خطا در ثبت‌نام: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت‌نام در Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">

<div class="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
    <h2 class="text-2xl font-bold text-center mb-6">ثبت‌نام در Dima Gallery</h2>

    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= $success ?></div>
        <a href="login.php" class="block text-center text-blue-500 hover:underline">ورود به حساب</a>
    <?php else: ?>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

            <div class="mb-4">
                <label class="block text-gray-700 mb-2" for="name">نام</label>
                <input type="text" id="name" name="name" required
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 mb-2" for="email">ایمیل</label>
                <input type="email" id="email" name="email" required
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-6">
                <label class="block text-gray-700 mb-2" for="password">رمز عبور</label>
                <input type="password" id="password" name="password" required
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <button type="submit"
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200">
                ثبت‌نام
            </button>
        </form>

        <p class="mt-4 text-center">
            حساب دارید؟ <a href="login.php" class="text-blue-500 hover:underline">وارد شوید</a>
        </p>
    <?php endif; ?>
</div>

</body>
</html>