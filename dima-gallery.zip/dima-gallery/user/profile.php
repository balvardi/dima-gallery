<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!is_logged_in()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// دریافت اطلاعات کاربر
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// دریافت طرح‌های کاربر
$stmt = $pdo->prepare("SELECT id, title, preview_image, status, downloads FROM designs WHERE user_id = ?");
$stmt->execute([$user_id]);
$designs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پروفایل - <?= htmlspecialchars($user['name']) ?></title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include '../admin/sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <div class="bg-white rounded shadow p-6">
        <div class="flex items-center mb-6">
            <div class="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xl">
                <?= strtoupper(substr($user['name'], 0, 1)) ?>
            </div>
            <div class="mr-4">
                <h1 class="text-2xl font-bold"><?= htmlspecialchars($user['name']) ?></h1>
                <p class="text-gray-500"><?= htmlspecialchars($user['email']) ?></p>
                <p class="text-sm text-gray-400">عضو از <?= date('Y/m/d', strtotime($user['created_at'])) ?></p>
            </div>
        </div>

        <!-- Social Links -->
        <div class="mb-6">
            <h2 class="font-semibold mb-2">شبکه‌های اجتماعی</h2>
            <div class="space-y-2">
                <p><i class="fab fa-instagram text-pink-600 ml-2"></i> Instagram: <?= $user['instagram'] ?: 'ثبت نشده' ?></p>
                <p><i class="fab fa-linkedin text-blue-600 ml-2"></i> LinkedIn: <?= $user['linkedin'] ?: 'ثبت نشده' ?></p>
                <p><i class="fab fa-twitter text-blue-400 ml-2"></i> Twitter: <?= $user['twitter'] ?: 'ثبت نشده' ?></p>
                <p><i class="fas fa-globe text-green-600 ml-2"></i> وبسایت: 
                    <?php if ($user['website']): ?>
                        <a href="<?= htmlspecialchars($user['website']) ?>" target="_blank" class="text-blue-500 hover:underline"><?= $user['website'] ?></a>
                    <?php else: ?>
                        ثبت نشده
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <!-- Share Profile -->
        <div class="mb-6">
            <h2 class="font-semibold mb-2">اشتراک گذاری پروفایل</h2>
            <div class="flex space-x-2 space-x-reverse">
                <a href="https://twitter.com/intent/tweet?url=<?= urlencode("http://yoursite.com/user/profile.php?id={$user_id}") ?>&text=<?= urlencode("مشاهده پروفایل {$user['name']}") ?>"
                   target="_blank" class="bg-blue-400 text-white px-3 py-1 rounded hover:bg-blue-500">
                    <i class="fab fa-twitter ml-1"></i> توییتر
                </a>
                <a href=" https://www.facebook.com/sharer/sharer.php?u=<?= urlencode("http://yoursite.com/user/profile.php?id={$user_id}") ?>"
                   target="_blank" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">
                    <i class="fab fa-facebook-f ml-1"></i> فیسبوک
                </a>
                <a href=" https://www.linkedin.com/shareArticle?mini=true&url=<?= urlencode("http://yoursite.com/user/profile.php?id={$user_id}") ?>&title=<?= urlencode("پروفایل {$user['name']}") ?>"
                   target="_blank" class="bg-blue-700 text-white px-3 py-1 rounded hover:bg-blue-800">
                    <i class="fab fa-linkedin-in ml-1"></i> لینکدین
                </a>
            </div>
        </div>

        <!-- User Designs -->
        <div>
            <h2 class="font-semibold mb-2">طرح‌های من</h2>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                <?php foreach ($designs as $d): ?>
                    <div class="card bg-white rounded shadow overflow-hidden">
                        <img src="<?= htmlspecialchars($d['preview_image'] ?? '../assets/images/default.jpg') ?>"
                             alt="<?= htmlspecialchars($d['title']) ?>" class="w-full h-32 object-cover">
                        <div class="p-2">
                            <p><?= htmlspecialchars($d['title']) ?></p>
                            <span class="text-xs <?= $d['status'] === 'approved' ? 'text-green-500' : 'text-yellow-500' ?>">
                                <?= $d['status'] === 'approved' ? 'منتشر شده' : 'در حال بررسی' ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>