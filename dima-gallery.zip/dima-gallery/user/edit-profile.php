<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!is_logged_in()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// دریافت اطلاعات فعلی
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $instagram = filter_input(INPUT_POST, 'instagram', FILTER_VALIDATE_URL);
    $linkedin = filter_input(INPUT_POST, 'linkedin', FILTER_VALIDATE_URL);
    $twitter = filter_input(INPUT_POST, 'twitter', FILTER_VALIDATE_URL);
    $website = filter_input(INPUT_POST, 'website', FILTER_VALIDATE_URL);

    $stmt = $pdo->prepare("UPDATE users SET name = ?, instagram = ?, linkedin = ?, twitter = ?, website = ? WHERE id = ?");
    $stmt->execute([$name, $instagram, $linkedin, $twitter, $website, $user_id]);
    $success = "اطلاعات با موفقیت بروزرسانی شد.";
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ویرایش پروفایل</title>
    <script src=" https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100">

<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">ویرایش پروفایل</h1>

    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 p-3 rounded mb-4"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 p-3 rounded mb-4"><?= $success ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">نام</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full px-4 py-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">اینستاگرام</label>
            <input type="url" name="instagram" value="<?= htmlspecialchars($user['instagram']) ?>" class="w-full px-4 py-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">لینکدین</label>
            <input type="url" name="linkedin" value="<?= htmlspecialchars($user['linkedin']) ?>" class="w-full px-4 py-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">توییتر</label>
            <input type="url" name="twitter" value="<?= htmlspecialchars($user['twitter']) ?>" class="w-full px-4 py-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">وبسایت</label>
            <input type="url" name="website" value="<?= htmlspecialchars($user['website']) ?>" class="w-full px-4 py-2 border rounded">
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">ذخیره تغییرات</button>
    </form>
</div>

</body>
</html>