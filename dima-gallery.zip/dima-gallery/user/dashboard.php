<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!is_logged_in()) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// لیست طرح‌های کاربر
$stmt = $pdo->prepare("SELECT id, title, status, downloads FROM designs WHERE user_id = ?");
$stmt->execute([$user_id]);
$designs = $stmt->fetchAll();

// آمار کلی
$total_designs = count($designs);
$total_downloads = array_sum(array_column($designs, 'downloads'));
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>داشبورد – <?= htmlspecialchars($_SESSION['name']) ?></title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include '../admin/sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">خوش آمدید، <?= $_SESSION['name'] ?></h1>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div class="bg-white p-6 rounded shadow flex items-center">
            <div class="text-blue-500 text-3xl ml-4"><i class="fas fa-image"></i></div>
            <div>
                <h3 class="text-gray-500 text-sm">طرح‌های شما</h3>
                <p class="text-2xl font-bold"><?= $total_designs ?></p>
            </div>
        </div>
        <div class="bg-white p-6 rounded shadow flex items-center">
            <div class="text-green-500 text-3xl ml-4"><i class="fas fa-download"></i></div>
            <div>
                <h3 class="text-gray-500 text-sm">دانلود‌ها</h3>
                <p class="text-2xl font-bold"><?= $total_downloads ?></p>
            </div>
        </div>
    </div>

    <!-- User Designs -->
    <div class="bg-white p-6 rounded shadow">
        <h2 class="text-xl font-bold mb-4">طرح‌های من</h2>
        <?php if ($designs): ?>
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="py-2 px-4 text-right">عنوان</th>
                        <th class="py-2 px-4 text-center">وضعیت</th>
                        <th class="py-2 px-4 text-center">دانلود</th>
                        <th class="py-2 px-4 text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($designs as $d): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-2 px-4"><?= htmlspecialchars($d['title']) ?></td>
                            <td class="py-2 px-4 text-center">
                                <span class="<?= $d['status'] === 'approved' ? 'text-green-600' : 'text-yellow-600' ?>">
                                    <?= $d['status'] === 'approved' ? 'منتشر شده' : 'در حال بررسی' ?>
                                </span>
                            </td>
                            <td class="py-2 px-4 text-center"><?= number_format($d['downloads']) ?></td>
                            <td class="py-2 px-4 text-center">
                                <a href="upload.php" class="text-blue-600 hover:text-blue-800 mx-2">ویرایش</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>شما هنوز طرحی آپلود نکرده‌اید.</p>
            <a href="upload.php" class="mt-2 inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">آپلود اولین طرح</a>
        <?php endif; ?>
    </div>
</div>

</body>
</html>