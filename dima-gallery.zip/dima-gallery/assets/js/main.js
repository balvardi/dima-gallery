// assets/js/main.js

document.addEventListener("DOMContentLoaded", function () {
    console.log("Dima Gallery Loaded");

    // Toggle Sidebar
    const sidebarToggle = document.getElementById("sidebar-toggle");
    const sidebar = document.getElementById("sidebar");

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener("click", function () {
            sidebar.classList.toggle("hidden");
        });
    }

    // Confirm Delete Action
    document.querySelectorAll(".btn-delete").forEach(btn => {
        btn.addEventListener("click", function (e) {
            if (!confirm("آیا مطمئن هستید؟")) {
                e.preventDefault();
            }
        });
    });

    // Auto-dismiss alerts
    setTimeout(() => {
        const alertBox = document.querySelector(".alert");
        if (alertBox) {
            alertBox.style.display = "none";
        }
    }, 5000);
});