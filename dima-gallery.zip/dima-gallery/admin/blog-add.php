<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

$error = '';
$success = '';

// دریافت دسته‌بندی‌ها
$stmt = $pdo->query("SELECT id, name FROM blog_categories ORDER BY name ASC");
$categories = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean_input($_POST['title']);
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['title'])));
    $excerpt = clean_input($_POST['excerpt']);
    $content = $_POST['content'];
    $category_id = intval($_POST['category_id']) ?: null;
    $status = $_POST['status'] === 'published' ? 'published' : 'draft';
    $author_id = $_SESSION['user_id'];

    if (!$title || !$content) {
        $error = "عنوان و محتوا الزامی هستند.";
    } else {
        // آپلود تصویر
        $featured_image = '';
        if (isset($_FILES['image']) && is_valid_file($_FILES['image'])) {
            $featured_image = generate_safe_filename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], "../assets/uploads/blog/" . $featured_image);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO blog_posts (title, slug, excerpt, content, featured_image, category_id, author_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $slug, $excerpt, $content, $featured_image, $category_id, $author_id, $status]);
            $success = "مقاله با موفقیت اضافه شد.";
        } catch (PDOException $e) {
            $error = "خطا در ذخیره مقاله: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>افزودن مقاله - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">افزودن مقاله جدید</h1>

    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= $success ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="bg-white shadow rounded p-6">
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">عنوان</label>
            <input type="text" name="title" required class="w-full border rounded px-3 py-2">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">خلاصه</label>
            <textarea name="excerpt" rows="3" class="w-full border rounded px-3 py-2"></textarea>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">محتوا</label>
            <textarea name="content" rows="10" class="w-full border rounded px-3 py-2" required></textarea>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">تصویر شاخص</label>
            <input type="file" name="image" accept="image/*" class="w-full border rounded px-3 py-2">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">دسته‌بندی</label>
            <select name="category_id" class="w-full border rounded px-3 py-2">