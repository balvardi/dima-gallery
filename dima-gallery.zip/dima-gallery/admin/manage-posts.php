<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// فقط ادمین می‌تواند وارد شود
if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

// تغییر وضعیت طرح
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['design_id'])) {
    $design_id = intval($_POST['design_id']);
    $action = $_POST['action'];

    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE designs SET status = 'approved' WHERE id = ?");
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE designs SET status = 'rejected' WHERE id = ?");
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM designs WHERE id = ?");
    }

    if (isset($stmt)) {
        $stmt->execute([$design_id]);
        header("Location: manage-posts.php");
        exit();
    }
}

// دریافت تمام طرح‌ها
$stmt = $pdo->query("
    SELECT d.id, d.title, d.status, d.created_at, u.name AS author 
    FROM designs d 
    JOIN users u ON d.user_id = u.id 
    ORDER BY d.created_at DESC
");
$designs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت طرح‌ها - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">مدیریت طرح‌ها</h1>

    <!-- Table -->
    <div class="bg-white rounded shadow overflow-hidden">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-4 text-right">عنوان</th>
                    <th class="py-3 px-4 text-right">نویسنده</th>
                    <th class="py-3 px-4 text-center">وضعیت</th>
                    <th class="py-3 px-4 text-center">تاریخ</th>
                    <th class="py-3 px-4 text-center">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($designs as $d): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4"><?= htmlspecialchars($d['title']) ?></td>
                        <td class="py-3 px-4"><?= htmlspecialchars($d['author']) ?></td>
                        <td class="py-3 px-4 text-center">
                            <span class="
                                <?= $d['status'] === 'approved' ? 'bg-green-100 text-green-800' : ($d['status'] === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') ?>
                                px-2 py-1 rounded-full text-xs
                            ">
                                <?= $d['status'] === 'approved' ? 'تأیید شده' : ($d['status'] === 'rejected' ? 'رد شده' : 'در حال بررسی') ?>
                            </span>
                        </td>
                        <td class="py-3 px-4 text-center"><?= date('Y/m/d', strtotime($d['created_at'])) ?></td>
                        <td class="py-3 px-4 text-center flex justify-center space-x-2 space-x-reverse">
                            <form method="post" class="inline">
                                <input type="hidden" name="design_id" value="<?= $d['id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <button type="submit" class="text-green-600 hover:text-green-800">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                            <form method="post" class="inline">
                                <input type="hidden" name="design_id" value="<?= $d['id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-times"></i>
                                </button>
                            </form>
                            <a href="../single.php?id=<?= $d['id'] ?>" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-eye"></i>
                            </a>
                            <form method="post" class="inline">
                                <input type="hidden" name="design_id" value="<?= $d['id'] ?>">
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="text-gray-600 hover:text-gray-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>