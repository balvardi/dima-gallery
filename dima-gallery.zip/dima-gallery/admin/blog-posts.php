<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

// دریافت مقالات
$stmt = $pdo->query("
    SELECT p.id, p.title, p.status, p.views, u.name AS author 
    FROM blog_posts p 
    JOIN users u ON p.author_id = u.id 
    ORDER BY p.created_at DESC
");
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مقالات - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">مقالات</h1>

    <a href="blog-add.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">افزودن مقاله جدید</a>

    <div class="bg-white rounded shadow overflow-hidden">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-4 text-right">عنوان</th>
                    <th class="py-3 px-4 text-center">نویسنده</th>
                    <th class="py-3 px-4 text-center">وضعیت</th>
                    <th class="py-3 px-4 text-center">بازدید</th>
                    <th class="py-3 px-4 text-center">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($posts as $post): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4"><?= htmlspecialchars($post['title']) ?></td>
                        <td class="py-3 px-4 text-center"><?= htmlspecialchars($post['author']) ?></td>
                        <td class="py-3 px-4 text-center">
                            <span class="<?= $post['status'] === 'published' ? 'text-green-600' : 'text-yellow-600' ?>">
                                <?= $post['status'] === 'published' ? 'منتشر شده' : 'پیش‌نویس' ?>
                            </span>
                        </td>
                        <td class="py-3 px-4 text-center"><?= number_format($post['views']) ?></td>
                        <td class="py-3 px-4 text-center flex justify-center space-x-2 space-x-reverse">
                            <a href="blog-edit.php?id=<?= $post['id'] ?>" class="text-blue-600 hover:text-blue-800"><i class="fas fa-edit"></i></a>
                            <a href="#" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>