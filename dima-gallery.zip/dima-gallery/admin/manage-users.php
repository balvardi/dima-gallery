<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// فقط ادمین می‌تواند وارد شود
if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

// تغییر نقش کاربر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_role'], $_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    $new_role = $_POST['role'] === 'admin' ? 'admin' : 'user';

    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->execute([$new_role, $user_id]);
    header("Location: manage-users.php");
    exit();
}

// حذف کاربر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'], $_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);

    // جلوگیری از حذف خود ادمین
    if ($user_id == $_SESSION['user_id']) {
        die("نمی‌توانید حساب خود را حذف کنید.");
    }

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    header("Location: manage-users.php");
    exit();
}

// دریافت تمام کاربران
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت کاربران - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">مدیریت کاربران</h1>

    <!-- Table -->
    <div class="bg-white rounded shadow overflow-hidden">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-4 text-right">نام</th>
                    <th class="py-3 px-4 text-right">ایمیل</th>
                    <th class="py-3 px-4 text-center">نقش</th>
                    <th class="py-3 px-4 text-center">تاریخ ثبت‌نام</th>
                    <th class="py-3 px-4 text-center">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4"><?= htmlspecialchars($u['name']) ?></td>
                        <td class="py-3 px-4"><?= htmlspecialchars($u['email']) ?></td>
                        <td class="py-3 px-4 text-center">
                            <form method="post" class="inline">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <select name="role" onchange="this.form.submit()" class="text-xs border rounded px-2 py-1">
                                    <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>کاربر</option>
                                    <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>ادمین</option>
                                </select>
                            </form>
                        </td>
                        <td class="py-3 px-4 text-center"><?= date('Y/m/d', strtotime($u['created_at'])) ?></td>
                        <td class="py-3 px-4 text-center flex justify-center space-x-2 space-x-reverse">
                            <form method="post" class="inline" onsubmit="return confirm('آیا مطمئن هستید؟')">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <input type="hidden" name="delete_user" value="1">
                                <button type="submit" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>