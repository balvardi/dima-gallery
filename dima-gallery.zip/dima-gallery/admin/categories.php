<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// فقط ادمین می‌تواند وارد شود
if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

$error = '';
$success = '';

// افزودن دسته جدید
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = clean_input($_POST['name']);
    $description = clean_input($_POST['description']);

    if (!$name) {
        $error = "لطفاً نام دسته را وارد کنید.";
    } else {
        try {
            // آپلود تصویر
            $image_path = '';
            if (isset($_FILES['image']) && is_valid_file($_FILES['image'])) {
                $image_path = generate_safe_filename($_FILES['image']['name']);
                move_uploaded_file($_FILES['image']['tmp_name'], "../assets/uploads/categories/" . $image_path);
            }

            $stmt = $pdo->prepare("INSERT INTO categories (name, description, image) VALUES (?, ?, ?)");
            $stmt->execute([$name, $description, $image_path]);
            $success = "دسته‌بندی با موفقیت اضافه شد.";
        } catch (PDOException $e) {
            $error = "خطا در ذخیره دسته‌بندی: " . $e->getMessage();
        }
    }
}

// حذف دسته
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_category'])) {
    $id = intval($_POST['category_id']);
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $success = "دسته‌بندی حذف شد.";
}

// دریافت تمام دسته‌ها
$stmt = $pdo->query("
    SELECT c.id, c.name, c.description, c.image, COUNT(d.id) AS design_count 
    FROM categories c
    LEFT JOIN designs d ON c.id = d.category_id
    GROUP BY c.id
");
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت دسته‌بندی‌ها - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Sidebar -->
<?php include 'sidebar.php'; ?>

<!-- Main Content -->
<div class="mr-64 p-6">
    <h1 class="text-2xl font-bold mb-6">مدیریت دسته‌بندی‌ها</h1>

    <!-- Form Add Category -->
    <div class="bg-white rounded shadow p-6 mb-8">
        <h2 class="text-xl font-semibold mb-4">افزودن دسته‌بندی جدید</h2>
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= $success ?></div>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">نام دسته</label>
                    <input type="text" name="name" required class="w-full border rounded px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">تصویر دسته</label>
                    <input type="file" name="image" class="w-full border rounded px-3 py-2">
                </div>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">توضیحات</label>
                <textarea name="description" rows="3" class="w-full border rounded px-3 py-2"></textarea>
            </div>
            <button type="submit" name="add_category"
                    class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                افزودن دسته
            </button>
        </form>
    </div>

    <!-- Table of Categories -->
    <div class="bg-white rounded shadow overflow-hidden">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-4 text-right">تصویر</th>
                    <th class="py-3 px-4 text-right">نام</th>
                    <th class="py-3 px-4 text-center">طرح‌ها</th>
                    <th class="py-3 px-4 text-center">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-3 px-4">
                            <img src="<?= $cat['image'] ? '../assets/uploads/categories/' . htmlspecialchars($cat['image']) : '../assets/images/default-category.jpg' ?>"
                                 alt="<?= htmlspecialchars($cat['name']) ?>" class="w-16 h-16 object-cover rounded">
                        </td>
                        <td class="py-3 px-4">
                            <strong><?= htmlspecialchars($cat['name']) ?></strong><br>
                            <small class="text-gray-500"><?= htmlspecialchars($cat['description']) ?></small>
                        </td>
                        <td class="py-3 px-4 text-center"><?= $cat['design_count'] ?> طرح</td>
                        <td class="py-3 px-4 text-center flex justify-center space-x-2 space-x-reverse">
                            <form method="post" onsubmit="return confirm('آیا مطمئن هستید؟')"
                                  class="inline">
                                <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                                <input type="hidden" name="delete_category" value="1">
                                <button type="submit" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>