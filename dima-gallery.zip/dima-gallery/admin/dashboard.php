<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!is_admin()) {
    header("Location: ../login.php");
    exit();
}

// آمار کاربران
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$total_users = $stmt->fetchColumn();

// آمار طرح‌ها
$stmt = $pdo->query("SELECT COUNT(*) FROM designs");
$total_designs = $stmt->fetchColumn();

// آمار دانلود‌ها
$stmt = $pdo->query("SELECT SUM(downloads) FROM designs");
$total_downloads = $stmt->fetchColumn();

// آخرین طرح‌ها
$stmt = $pdo->query("SELECT d.id, d.title, u.name AS user_name, d.status 
                     FROM designs d
                     JOIN users u ON d.user_id = u.id
                     ORDER BY d.created_at DESC LIMIT 5");
$latest_designs = $stmt->fetchAll();

// آخرین کاربران
$stmt = $pdo->query("SELECT name, email, created_at FROM users ORDER BY id DESC LIMIT 5");
$latest_users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>داشبورد ادمین - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100 text-gray-800">

<!-- Sidebar -->
<div class="flex min-h-screen">
    <aside class="w-64 bg-white shadow-md p-4">
        <h2 class="text-xl font-bold mb-6">پنل ادمین</h2>
        <nav class="space-y-2">
            <a href="dashboard.php" class="block px-4 py-2 rounded hover:bg-blue-100 text-blue-600">🏠 داشبورد</a>
            <a href="manage-posts.php" class="block px-4 py-2 rounded hover:bg-blue-100">🎨 مدیریت طرح‌ها</a>
            <a href="manage-users.php" class="block px-4 py-2 rounded hover:bg-blue-100">👥 مدیریت کاربران</a>
            <a href="../logout.php" class="block px-4 py-2 rounded hover:bg-red-100 text-red-600">خروج</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-6">
        <h1 class="text-3xl font-bold mb-6">خوش آمدید، <?= $_SESSION['name'] ?></h1>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded shadow">
                <h2 class="text-sm text-gray-500">کاربران</h2>
                <p class="text-2xl font-bold"><?= $total_users ?></p>
            </div>
            <div class="bg-white p-6 rounded shadow">
                <h2 class="text-sm text-gray-500">طرح‌ها</h2>
                <p class="text-2xl font-bold"><?= $total_designs ?></p>
            </div>
            <div class="bg-white p-6 rounded shadow">
                <h2 class="text-sm text-gray-500">دانلود‌ها</h2>
                <p class="text-2xl font-bold"><?= $total_downloads ?: 0 ?></p>
            </div>
        </div>

        <!-- Recent Designs -->
        <section class="mb-8">
            <h2 class="text-xl font-semibold mb-4">آخرین طرح‌ها</h2>
            <div class="bg-white shadow rounded overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">عنوان</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">نویسنده</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">وضعیت</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">عملیات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($latest_designs as $d): ?>
                            <tr>
                                <td class="px-6 py-4"><?= htmlspecialchars($d['title']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($d['user_name']) ?></td>
                                <td class="px-6 py-4 text-center">
                                    <?php if ($d['status'] === 'approved'): ?>
                                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده</span>
                                    <?php elseif ($d['status'] === 'rejected'): ?>
                                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">رد شده</span>
                                    <?php else: ?>
                                        <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">در حال بررسی</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-center space-x-2 space-x-reverse">
                                    <a href="#" class="text-blue-500 hover:underline">ویرایش</a>
                                    <a href="#" class="text-green-500 hover:underline">تأیید</a>
                                    <a href="#" class="text-red-500 hover:underline">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Recent Users -->
        <section>
            <h2 class="text-xl font-semibold mb-4">کاربران جدید</h2>
            <div class="bg-white shadow rounded overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">نام</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">ایمیل</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">تاریخ عضویت</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">عملیات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($latest_users as $u): ?>
                            <tr>
                                <td class="px-6 py-4"><?= htmlspecialchars($u['name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($u['email']) ?></td>
                                <td class="px-6 py-4"><?= $u['created_at'] ?></td>
                                <td class="px-6 py-4 text-center">
                                    <a href="#" class="text-red-500 hover:underline">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>

</body>
</html>