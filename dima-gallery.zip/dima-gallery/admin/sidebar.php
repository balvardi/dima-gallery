<aside class="w-64 h-screen fixed right-0 top-0 bg-blue-800 text-white">
    <div class="p-6 text-center font-bold text-xl border-b border-blue-700">پنل ادمین</div>
    <nav class="mt-4">
        <a href="dashboard.php" class="block py-3 px-6 hover:bg-blue-700"><i class="fas fa-tachometer-alt ml-2"></i> داشبورد</a>
        <a href="manage-posts.php" class="block py-3 px-6 hover:bg-blue-700"><i class="fas fa-image ml-2"></i> مدیریت طرح‌ها</a>
        <a href="manage-users.php" class="block py-3 px-6 hover:bg-blue-700"><i class="fas fa-users ml-2"></i> مدیریت کاربران</a>
        <a href="categories.php" class="block py-3 px-6 hover:bg-blue-700"><i class="fas fa-tags ml-2"></i> دسته‌بندی‌ها</a>
        <a href="../user/upload.php" class="block py-3 px-6 hover:bg-blue-700"><i class="fas fa-upload ml-2"></i> آپلود جدید</a>
        <a href="logout.php" class="block py-3 px-6 hover:bg-red-700 mt-4"><i class="fas fa-sign-out-alt ml-2"></i> خروج</a>
    </nav>
</aside>