<?php
header("Content-Type: application/json");

require_once '../includes/db.php';

$stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => "success",
    "count" => count($categories),
    "data" => $categories
]);
?>