<?php
header("Content-Type: application/json");

require_once '../includes/db.php';

$stmt = $pdo->query("
    SELECT id, title, excerpt, featured_image, views, created_at 
    FROM blog_posts 
    WHERE status = 'published' 
    ORDER BY created_at DESC
");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => "success",
    "count" => count($posts),
    "data" => $posts
]);
?>