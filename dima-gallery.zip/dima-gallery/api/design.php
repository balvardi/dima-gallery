<?php
header("Content-Type: application/json");

require_once '../includes/db.php';

$id = intval($_GET['id']);

$stmt = $pdo->prepare("
    SELECT d.id, d.title, d.description, d.preview_image, d.file_path, d.downloads, d.views, d.created_at, c.name AS category 
    FROM designs d
    JOIN categories c ON d.category_id = c.id
    WHERE d.id = ? AND d.status = 'approved'
");
$stmt->execute([$id]);
$design = $stmt->fetch(PDO::FETCH_ASSOC);

if ($design) {
    echo json_encode(["status" => "success", "data" => $design]);
} else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "طرح یافت نشد"]);
}
?>