<?php
header("Content-Type: application/json");

require_once '../includes/db.php';

$id = intval($_GET['id']);

$stmt = $pdo->prepare("
    SELECT id, title, content, featured_image, views, created_at 
    FROM blog_posts 
    WHERE id = ? AND status = 'published'
");
$stmt->execute([$id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if ($post) {
    echo json_encode(["status" => "success", "data" => $post]);
} else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "مقاله یافت نشد"]);
}
?>