<?php
header("Content-Type: application/json");

require_once '../includes/db.php';

$stmt = $pdo->query("
    SELECT d.id, d.title, d.description, d.preview_image, d.downloads, d.views, d.created_at, c.name AS category 
    FROM designs d
    JOIN categories c ON d.category_id = c.id
    WHERE d.status = 'approved'
    ORDER BY d.created_at DESC
");
$designs = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => "success",
    "count" => count($designs),
    "data" => $designs
]);
?>