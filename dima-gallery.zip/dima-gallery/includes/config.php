<?php
// includes/config.php

define('SITE_NAME', 'Dima Gallery');
define('BASE_URL', 'http://localhost/dima-gallery');
define('UPLOAD_DIR', 'assets/uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/svg+xml']);
define('ALLOWED_FILE_TYPES', ['application/zip', 'application/x-zip-compressed', 'image/jpeg', 'image/png', 'image/svg+xml']);
?>