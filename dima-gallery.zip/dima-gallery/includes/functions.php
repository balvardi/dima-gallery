<?php
// includes/functions.php

// فیلتر کردن ورودی‌های کاربر
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// اعتبارسنجی فایل آپلود شده
function is_valid_file($file) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/svg+xml', 'application/zip', 'application/x-zip-compressed'];
    $max_size = 10 * 1024 * 1024; // 10MB

    if (!in_array($file['type'], $allowed_types)) {
        return false;
    }

    if ($file['size'] > $max_size) {
        return false;
    }

    return true;
}

// تولید نام تصادفی برای فایل
function generate_safe_filename($filename) {
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    return uniqid('upload_', true) . '.' . $ext;
}

// ثبت لاگ امنیتی (اختیاری)
function log_security_event($message) {
    error_log("[Security] " . date("Y-m-d H:i:s") . " - " . $message . "\n", 3, __DIR__ . '/../logs/security.log');
}
?>