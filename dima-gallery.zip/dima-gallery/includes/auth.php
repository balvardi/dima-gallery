<?php
// includes/auth.php

session_start();

// چک کردن لاگین بودن کاربر
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// چک کردن نقش ادمین
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// ریدایرکت به صفحه‌ای مشخص
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// تولید CSRF Token
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(50));
    }
    return $_SESSION['csrf_token'];
}

// اعتبارسنجی CSRF Token
function verify_csrf_token($token) {
    return hash_equals(csrf_token(), $token);
}

// حذف سشن کاربر
function logout() {
    session_unset();
    session_destroy();
    redirect('login.php');
}
?>