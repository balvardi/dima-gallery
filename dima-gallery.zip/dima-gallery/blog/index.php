<?php
require_once '../includes/db.php';

$stmt = $pdo->query("
    SELECT p.id, p.title, p.excerpt, p.featured_image, p.views, p.created_at, u.name AS author 
    FROM blog_posts p 
    JOIN users u ON p.author_id = u.id 
    WHERE p.status = 'published'
    ORDER BY p.created_at DESC LIMIT 12
");
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>وبلاگ - Dima Gallery</title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-white shadow p-4">
    <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-xl font-bold">وبلاگ</h1>
        <a href="../index.php" class="text-blue-500 hover:underline">بازگشت به خانه</a>
    </div>
</header>

<!-- Blog Posts -->
<div class="container mx-auto px-4 py-8">
    <h2 class="text-2xl font-bold mb-6">آخرین مقالات</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($posts as $post): ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <img src="<?= htmlspecialchars($post['featured_image'] ?? '../assets/images/default-blog.jpg') ?>"
                     alt="<?= htmlspecialchars($post['title']) ?>" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="font-semibold text-lg"><?= htmlspecialchars($post['title']) ?></h3>
                    <p class="text-gray-600 mt-2"><?= htmlspecialchars($post['excerpt']) ?></p>
                    <div class="mt-4 text-sm text-gray-500">
                        <p><?= date('Y/m/d', strtotime($post['created_at'])) ?></p>
                        <p><?= htmlspecialchars($post['author']) ?></p>
                    </div>
                    <a href="single.php?id=<?= $post['id'] ?>" class="text-blue-500 hover:underline mt-2 inline-block">ادامه مطلب</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>