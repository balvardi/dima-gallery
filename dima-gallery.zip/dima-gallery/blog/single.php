<?php
require_once '../includes/db.php';

$post_id = intval($_GET['id']);

// بروزرسانی بازدید
$stmt = $pdo->prepare("UPDATE blog_posts SET views = views + 1 WHERE id = ?");
$stmt->execute([$post_id]);

// دریافت مقاله
$stmt = $pdo->prepare("
    SELECT p.*, u.name AS author 
    FROM blog_posts p 
    JOIN users u ON p.author_id = u.id 
    WHERE p.id = ? AND p.status = 'published'
");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if (!$post) {
    die("مقاله مورد نظر یافت نشد.");
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($post['title']) ?></title>
    <script src="https://cdn.tailwindcss.com "></script>
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-white shadow p-4">
    <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-xl font-bold">وبلاگ</h1>
        <a href="index.php" class="text-blue-500 hover:underline">بازگشت به لیست</a>
    </div>
</header>

<!-- Post Content -->
<div class="container mx-auto px-4 py-8">
    <div class="bg-white rounded shadow p-6">
        <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($post['title']) ?></h1>
        <div class="text-gray-500 mb-4">
            نوشته شده توسط <?= htmlspecialchars($post['author']) ?> در <?= date('Y/m/d', strtotime($post['created_at'])) ?>
        </div>
        <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="w-full h-64 object-cover rounded mb-6">
        <div class="prose max-w-none">
            <?= nl2br(htmlspecialchars($post['content'])) ?>
        </div>
    </div>
</div>

</body>
</html>