<?php
require_once 'includes/db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("UPDATE designs SET downloads = downloads + 1 WHERE id = ?");
    $stmt->execute([$id]);
}
?>