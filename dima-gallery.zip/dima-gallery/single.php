<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$design_id = intval($_GET['id']);

// بروزرسانی بازدید
$stmt = $pdo->prepare("UPDATE designs SET views = views + 1 WHERE id = ?");
$stmt->execute([$design_id]);

// دریافت اطلاعات طرح
$stmt = $pdo->prepare("
    SELECT d.*, u.name AS author 
    FROM designs d 
    JOIN users u ON d.user_id = u.id 
    WHERE d.id = ?
");
$stmt->execute([$design_id]);
$design = $stmt->fetch();

if (!$design) {
    die("طرح مورد نظر یافت نشد.");
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($design['title']) ?></title>
    <script src="https://cdn.tailwindcss.com "></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css " rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-white shadow p-4">
    <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-xl font-bold">Dima Gallery</h1>
        <a href="index.php" class="text-blue-500 hover:underline">بازگشت به خانه</a>
    </div>
</header>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8">
    <div class="bg-white rounded shadow p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Image -->
            <div>
                <img src="<?= htmlspecialchars($design['preview_image']) ?>"
                     alt="<?= htmlspecialchars($design['title']) ?>" class="w-full h-auto rounded shadow">
            </div>

            <!-- Info -->
            <div>
                <h2 class="text-2xl font-bold mb-2"><?= htmlspecialchars($design['title']) ?></h2>
                <p class="text-gray-700 mb-4"><?= nl2br(htmlspecialchars($design['description'])) ?></p>

                <div class="mb-4">
                    <p><strong>نویسنده:</strong> <?= htmlspecialchars($design['author']) ?></p>
                    <p><strong>بازدید:</strong> <?= number_format($design['views']) ?></p>
                    <p><strong>دانلود:</strong> <?= number_format($design['downloads']) ?></p>
                    <p><strong>تاریخ:</strong> <?= date('Y/m/d', strtotime($design['created_at'])) ?></p>
                </div>

                <a href="<?= htmlspecialchars($design['file_path']) ?>"
                   download
                   onclick="updateDownloads(<?= $design_id ?>)"
                   class="inline-block bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">
                    <i class="fas fa-download ml-2"></i> دانلود فایل
                </a>
            </div>
        </div>

        <!-- Share Buttons -->
        <div class="mt-8">
            <h3 class="font-semibold mb-2">اشتراک گذاری</h3>
            <div class="flex space-x-2 space-x-reverse">
                <a href="https://twitter.com/intent/tweet?url=<?= urlencode("http://yoursite.com/single.php?id={$design_id}") ?>&text=<?= urlencode("مشاهده طرح {$design['title']}") ?>"
                   target="_blank" class="bg-blue-400 text-white px-3 py-1 rounded hover:bg-blue-500">
                    <i class="fab fa-twitter ml-1"></i> توییتر
                </a>
                <a href=" https://www.facebook.com/sharer/sharer.php?u=<?= urlencode("http://yoursite.com/single.php?id={$design_id}") ?>"
                   target="_blank" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">
                    <i class="fab fa-facebook-f ml-1"></i> فیسبوک
                </a>
                <a href=" https://www.linkedin.com/shareArticle?mini=true&url=<?= urlencode("http://yoursite.com/single.php?id={$design_id}") ?>&title=<?= urlencode("طرح {$design['title']}") ?>"
                   target="_blank" class="bg-blue-700 text-white px-3 py-1 rounded hover:bg-blue-800">
                    <i class="fab fa-linkedin-in ml-1"></i> لینکدین
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function updateDownloads(id) {
    fetch(`download-count.php?id=${id}`, { method: 'GET' });
}
</script>

</body>
</html>