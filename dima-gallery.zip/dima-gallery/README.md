# Dima Gallery - Clone of Freepik.com

A simple and secure PHP clone of [Freepik.com](https://www.freepik.com ) for sharing design assets.  
Users can upload free designs, photos, vectors, and illustrations, which will be published after admin approval.

## Features

- User Registration & Login
- Email Verification (optional)
- Upload Design Files (Images, ZIPs, SVGs, etc.)
- Admin Approval System
- Admin Dashboard to Manage Posts & Users
- Responsive UI using Tailwind CSS
- Secure Authentication & File Upload
- MIT License – Free to use and modify

## Requirements

- PHP 7.4+
- MySQL
- Apache or Nginx
- Composer (optional)
- Tailwind CSS (included)

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/balvardi/dima-gallery.git 