<?php
require_once 'includes/db.php';

// دریافت آخرین دسته‌بندی‌ها
$stmt = $pdo->query("SELECT * FROM categories ORDER BY id DESC LIMIT 6");
$categories = $stmt->fetchAll();

// دریافت آخرین طرح‌ها
$stmt = $pdo->query("SELECT d.id, d.title, d.preview_image, d.created_at, u.name AS author 
                     FROM designs d 
                     JOIN users u ON d.user_id = u.id 
                     WHERE d.status = 'approved' 
                     ORDER BY d.created_at DESC LIMIT 12");
$designs = $stmt->fetchAll();

// دریافت آخرین کاربران
$stmt = $pdo->query("SELECT name, email, created_at FROM users ORDER BY id DESC LIMIT 8");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>Dima Gallery - طرح‌های رایگان</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="manifest.json">
    <script src="https://cdn.tailwindcss.com "></script>
    <style>
        .card:hover { transform: translateY(-5px); transition: all 0.3s ease; }
    </style>
</head>
<body class="bg-white text-gray-800">

<!-- Manifest for PWA -->
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js').then(function(registration) {
            console.log('ServiceWorker registered with scope: ', registration.scope);
        }, function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}
</script>

<!-- Header -->
<header class="bg-blue-700 text-white p-4 shadow-md">
    <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-xl font-bold">Dima Gallery</h1>
        <nav class="space-x-4 space-x-reverse">
            <a href="login.php" class="hover:underline">ورود</a>
            <a href="register.php" class="hover:underline">ثبت‌نام</a>
            <a href="#" class="hover:underline">آپلود</a>
        </nav>
    </div>
</header>

<!-- Slider -->
<section class="relative h-64 md:h-96 overflow-hidden">
    <div class="absolute inset-0 bg-cover bg-center"
         style="background-image: url('https://picsum.photos/seed/slider/1600/600 ');">
        <div class="flex items-center justify-center h-full bg-black bg-opacity-50 text-white">
            <h2 class="text-3xl md:text-5xl font-bold text-center px-4">به Dima Gallery خوش آمدید</h2>
        </div>
    </div>
</section>

<!-- Categories -->
<section class="py-10 bg-gray-50">
    <div class="container mx-auto px-4">
        <h2 class="text-2xl font-bold mb-6 text-center">دسته‌بندی‌ها</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <?php foreach ($categories as $cat): ?>
                <a href="#" class="block text-center p-4 border rounded hover:bg-blue-100">
                    <?= htmlspecialchars($cat['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Latest Designs -->
<section class="py-10">
    <div class="container mx-auto px-4">
        <h2 class="text-2xl font-bold mb-6 text-center">آخرین طرح‌ها</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($designs as $d): ?>
                <div class="card bg-white rounded shadow hover:shadow-lg">
                    <img src="<?= htmlspecialchars($d['preview_image'] ?? 'assets/images/default.jpg') ?>"
                         alt="<?= htmlspecialchars($d['title']) ?>" class="w-full h-48 object-cover rounded-t">
                    <div class="p-4">
                        <h3 class="font-semibold"><?= htmlspecialchars($d['title']) ?></h3>
                        <p class="text-sm text-gray-500">توسط <?= htmlspecialchars($d['author']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Recent Users -->
<section class="py-10 bg-gray-50">
    <div class="container mx-auto px-4">
        <h2 class="text-2xl font-bold mb-6 text-center">کاربران جدید</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <?php foreach ($users as $u): ?>
                <div class="text-center">
                    <div class="w-12 h-12 mx-auto rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                        <?= strtoupper(substr($u['name'], 0, 1)) ?>
                    </div>
                    <p class="mt-2 text-sm"><?= htmlspecialchars($u['name']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-gray-800 text-white py-6">
    <div class="container mx-auto px-4 text-center">
        <p>© 2025 Dima Gallery. تمامی حقوق محفوظ است.</p>
        <div class="mt-2">
            <a href="#" class="mx-2 hover:underline">درباره ما</a>
            <a href="#" class="mx-2 hover:underline">تماس با ما</a>
            <a href="#" class="mx-2 hover:underline">قوانین</a>
        </div>
    </div>
</footer>

</body>
</html>